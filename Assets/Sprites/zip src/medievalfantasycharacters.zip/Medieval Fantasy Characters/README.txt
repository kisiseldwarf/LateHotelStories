
Thank you for acquire this asset.

All content in this folder has been created by Isra "ismartal" Maraver
Email: isramaraver@gmail.com
Discord: ismartal#3590

This asset pack can be used for any type of project, including commercial without any limitation, credits are not mandatory but very appreciated.

These assets were created with Aseprite.

If you have any questions or problems please do not hesitate to contact me.


									----------------------------------------------


Content list:

All sprites are in PNG images of 32x32 px. Some sprites, although they retain the same resolution, occupy half or double of the space depending on their size, 16 or 64 px

Characters:
	
	- 40 diferent heads x 7 skintone colors.
	- 4 animations for the body: run, walk, jump and idle. With 12 diferent colors.
	- Hands with the diferent head skintones and body colors
	- 30 haistyles x 8 diferent colors
	- 30 facialhair styles x 8 diferent colors

Wardrobe:

	- 49 cloth hats x 8 diferent colors
	- 5 straw hats
	- 41 leather hats
	- 48 metal hats 
	- 22 metal hats x 8 diferent colors

Weapons:

	- 12 axes
	- 8 daggers
	- 14 blunt weapons
	- 18 polearms
	- 13 swords
	- 7 bows
	- 4 crossbows
	- 2 slings
	- arrow, bolts and stone projectiles (bullets).
	- 5 throwing weapons: axe, knife, shuriken, dart, spear.
	- 7 wands
	- 13 staffs

Effects:

	- character death animation
	- 13 fire effects
	- 12 ice effects
	- 12 magic effects
	- 11 poison effects
	- 10 melee weapon effects
									----------------------------------------------


New update:
----------

Characters:

	- 3 new races, goblin, orc and elf.
	- 40 diferent heads x 8 skintone colors for elf.
	- 40 diferent heads x 4 skintone colors for orc and goblin.

Weapons:

	- 10 axes
	- 6 daggers
	- 6 blunt weapons
	- 16 polearms
	- 20 swords
	- 5 wands
	- 12 staffs

Animated firearms:

	- 6 pistols
	- 2 arquebus
	- 2 musket
	- 2 blunderbuss
	- 1 repeater musket
	- bullets and shot fx

Mounts:

	- horse with 20 diferent colors and 63 saddles
	- elk with 8 diferent colors and 54 saddles
	- wild boar with 6 diferent colors and 17 saddles
	- wolf with 8 diferent colors and 10 saddles
	- chariots, 11 diferent styles 
	(all with run and walk animations)
	


	



